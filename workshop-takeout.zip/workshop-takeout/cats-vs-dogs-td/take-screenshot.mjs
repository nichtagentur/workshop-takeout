import puppeteer from 'puppeteer';

const browser = await puppeteer.launch({
  headless: true,
  args: ['--no-sandbox', '--disable-setuid-sandbox']
});
const page = await browser.newPage();
await page.setViewport({ width: 960, height: 640 });
await page.goto('file:///home/student/Projects/cats-vs-dogs-td/index.html');
await page.waitForSelector('#overlay');

// Click Play
await page.click('#overlay-content button');
await new Promise(r => setTimeout(r, 500));

// Place towers and start waves
await page.evaluate(() => {
  function place(col, row, type) {
    if (grid[row][col]) return false;
    const cost = TOWER_TYPES[type].cost;
    if (money < cost) return false;
    money -= cost;
    towers.push(new Tower(col, row, type));
    grid[row][col] = true;
    updateHUD();
    return true;
  }
  place(3, 2, 'laser');
  place(7, 5, 'scratch');
  place(14, 6, 'yarn');
  place(19, 10, 'sniper');
  WaveManager.startWave();
});

// Wait for enemies to spawn and engage
await new Promise(r => setTimeout(r, 3000));

// Start wave 2 as well for more action
await page.evaluate(() => {
  if (!WaveManager.active) WaveManager.startWave();
});
await new Promise(r => setTimeout(r, 2500));

await page.screenshot({ path: '/home/student/Screenshots/catsvsdogs-action.png' });
console.log('Screenshot saved');
await browser.close();
