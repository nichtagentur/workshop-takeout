# Projects Directory

This is the working directory for AI workshop projects.

**Quick commands:**
```bash
claude+ "create new project"
codex+ "build something"
gemini+ "help me code"
```

See `~/.claude/CLAUDE.md` for full configuration.
